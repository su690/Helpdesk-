import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow } from 'enzyme';
import { Route } from 'react-router-dom';
import { MemoryRouter} from 'react-router';
import { mount } from 'enzyme';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';
import DisplayProducts from './Components/DisplayProducts.js';
import ViewCart from './Components/ViewCart.js';
import Service from './Service/Service.js';
import productList from './articles.json';

describe('Routing in App component', () => {
    
//     	it('renders without crashing', () => {
		
// 		try {
// 			const div = document.createElement('div');
// 			ReactDOM.render(<CoursesOffered />, div);
// 			ReactDOM.unmountComponentAtNode(div);
// 		}
// 		catch (e) {
// 		    console.log(e);
// 			fail('Home component did NOT mount properly');
// 		}
// 	});

it('should show DisplayProducts component when Display Products Link is clicked', () => {

	  try{
	      	const history = createMemoryHistory()
    		const { container, getByText } = render(
    		<Router history={history}>
    		  <App/>
    		</Router>
	  )
	           fireEvent.click(getByText(/Display Products/i))
		        expect(container.innerHTML).toMatch('Display Products')
		}	 	  	  	 			     	    	 	
		catch(e){
		  //   console.log(e);
			fail("Expected Text 'About Us' is not displayed correctly.");
		}
  });
  
  
//     it('should show Course component when Admission Info Link is clicked', () => {
	
// 	  try{
// 	      	const history = createMemoryHistory()
//     		const { container, getByText } = render(
//     		<Router history={history}>
//     		  <App />
//     		</Router>
// 	  )
// 	        fireEvent.click(getByText(/Admission Info/i))
// 			expect(container.innerHTML).toMatch('Admission Info')
// 		}
// 		catch(e){
// 		  //   console.log(e);
// 			fail("Expected Text 'Admission Info' is not displayed correctly.");
// 		}
//   });
  
//   it('should show Admission component when Admission Enquiry Link is clicked', () => {
	
// 	  try{
// 	      	const history = createMemoryHistory()
// 		const { container, getByText } = render(
// 		<Router history={history}>
// 		  <App />
// 		</Router>
// 	  )
//             	  fireEvent.click(getByText(/Admission Enquiry/i))
// 				  expect(container.innerHTML).toMatch('Admission Enquiry')
// 		}	 	  	  	 			     	    	 	
// 		catch(e){
// 			fail("Expected Text 'Admission Enquiry' is not displayed correctly.");
// 		}
//   });
  
//   it('should apply navigation styles',() => {
		
//         try{
//         	    const wrapper1 = mount(<App />);
//             	const style = wrapper1.find('nav').at(0);
//             	var data = style.prop('style');
//             // 	console.log("#########", data)
//     			expect(data).toMatchObject({'borderBottom':'solid 1px','paddingBottom': '1rem','fontWeight':'bolder','backgroundColor':'#00ffff'})
// 		}
// 		catch(e){
// 		  //  console.log(e);
// 			fail("Styles NOT applied properly to nav tag in App component");
// 		}
    
// });

// it('should apply h1 tag styles to the heading',() => {
		
//         try{
//         	    const wrapper1 = mount(<App />);
//             	const style = wrapper1.find('h1').at(0);
//             	var data = style.prop('style');
//                 // console.log("$$$",data)
//             	expect(data).toMatchObject({'textAlign':'center', 'color':'#00ffff'})
//     	}
// 		catch(e){
// 		  //  console.log(e);
// 			fail("Styles NOT applied properly to <h1> tag in App component");
// 		}
    
// }); 

  
});

// //  describe('CoursesOffered Component', () => {	 	  	  	 			     	    	 	
  
// //   it('should display course details as list using key with  props',() => {
// //     	try {
// // 	      const wrapper = mount(<CoursesOffered/>);
// // 	   //   console.log("$$$",wrapper.text())
// //           expect(wrapper.text()).toMatch("Biomedical");
// //     	}catch(e){
// //     	    fail("Displayed courses Offered data is NOT correct.")
// //     	}
// //     });
    
// //  it('should use map keyword for course diaplay',() => {
// //     	try {
// // 	      if(process.env.flag1!="true")
// //           fail("'map' keyword is NOT used for iteration");
// //     	}catch(e){
// //     	    fail("'map' keyword is NOT used for iteration");
// //     	}
// //     }); 
// // it('should use key keyword for course display',() => {
// //     	try {
// // 	      if(process.env.flag2!="true")
// //           fail("'key'  is NOT implemented");
// //     	}catch(e){
// //     	    fail("'key' is NOT implemented");
// //     	}
// //     }); 
// //  });
 
// //   describe('Admission info page', () => {
// //   it('should implement the onChange while entering course id', () => {
// //       try {
// //           const component = shallow(<Programme  progCourse='UG1'/>);
// //             // component.find('input').simulate('change', { target: {value: 'UG1' }});
// //     // console.log("%%%",component.text())
// //             expect(component.text().toLowerCase()).toMatch("aeronautical");
// //       }	 	  	  	 			     	    	 	
// // 		catch (e) {
// // 			throw new Error('OnChange Event NOT implemented correctly');
// // 		}
// //     });
   
// //     it('should apply styles on p tag',() => {
		
// //         try{
// //         	    const wrapper1 = shallow(<Course />);
// //             	const style = wrapper1.find('p').at(0);
// //             // 	console.log("SSSSSSSSssss",style)
// //             	var data = style.prop('style');
// //                 // console.log("$$$data$$$",data)
// //             	expect(data).toMatchObject({'color':'#ffd700','fontWeight':'bolder','fontSize':'20px',  'textAlign': 'center', 'textTransform': 'uppercase'})
    
// // 		}
		
	
// // 		catch(e){
// // 		  //  console.log(e);
// // 			fail("Styles NOT applied properly to <p> tag in Course component");
// // 		}
    
// // }); 

// // });


// //  describe('Admission component', () => {
  	
// // 	it('should display the message after clicking button in Admission enquiry form', () => {
	    
// // 	   // window.alert = jest.fn();
	
// // 		try{
// // 			const component = mount(<Admission/>);
// //     		component.find('#name').simulate('change', {target: {value: 'Noel'}});
// //     		component.find('#email').simulate('change', {target: {value: 'noel@outlook.com'}});
// //     		component.find('button').simulate('click');
	
// // 		  //console.log("@@@",component.text());
// // 			expect(component.text()).toMatch("Noel, we have received your application. All further information will be mailed to noel@outlook.com");
// // 		}	 	  	  	 			     	    	 	
// // 		catch(e){
// // 			fail("After the button is clicked in the Admission enquiry form, the confirmation message is not displayed ");
// // 		}
		
// // 	});
	
// // 	it('should apply h3 styles',() => {
		
// //         try{
// //         	    const wrapper1 = mount(<Admission />);
// //             	const style = wrapper1.find('h3').at(0);
// //             	var data = style.prop('style');
// //                 // console.log("$$$",data)
// //             	expect(data).toMatchObject({height:'50px',color:'#ffffff',padding:'10px',backgroundColor:'#81807e'})
    
// // 		}
// // 		catch(e){
// // 		  //  console.log(e);
// // 			fail("Styles NOT applied properly to <h3> tag in Admission component");
// // 		}
    
// // }); 

	
// // 	it('should apply button styles',() => {
		
// //         try{
// //         	    const wrapper1 = mount(<Admission />);
// //             	const style = wrapper1.find('button').at(0);
// //             	var data = style.prop('style');
            
// //     			expect(data).toMatchObject({ 'backgroundColor':'#00ffff','height':'30px','textAlign':'center','width':'125px'})
// // 		}
// // 		catch(e){
// // 		  //  console.log(e);
// // 			fail("Styles NOT applied properly to button tag in Admission component");
// // 		}	 	  	  	 			     	    	 	
    
// // });


// // it('should apply styles for div tag with id as display1',() => {
		
// //         try{
// //         	    const wrapper1 = mount(<Admission />);
// //             	const style = wrapper1.find('#display1').at(0);
// //             	var data = style.prop('style');
// //             // console.log(data)
// //     			expect(data).toMatchObject({ 'height':"30px",'width':"auto",'backgroundColor': '#d3eaf1','padding':"3px",'color':'red','fontWeight':'bolder'})
// // 		}
// // 		catch(e){
// // 		  //  console.log(e);
// // 			fail("Styles NOT applied properly to div tag with id as display1 in Admission component");
// // 		}
    
// // });

	
//  });	

	
	



 


// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/learn react/i);
//   expect(linkElement).toBeInTheDocument();
// });
	 	  	  	 			     	    	 	
